RawCopyUtil — Sample Files for App Review
==========================================

RAW_originals/  : 10 RAW files (IMG_0001-0010.DNG), simulating camera originals
JPG_selected/   : 6 JPG files simulating client-selected photos
                  - IMG_0001/0003/0005/0007/0009.JPG match RAW files
                  - IMG_0011.JPG has NO matching RAW (to demonstrate the
                    "No RAW" counter)

See the App Review notes for step-by-step testing instructions.
